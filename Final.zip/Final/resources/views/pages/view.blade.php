@extends('layout.master')

@section('title')
    View Event
@endsection
@section('content')
    <div class="container">
        <div class="col-md-8 offset-md-2">
            
            <div class="addbox">
                <b>Event Details</b>
                <br><br><br>
                <div class="details">
                    </br>Schedule: {{$task->date}}</br> 
                    </br>Venue: {{$task->venue}}</br> 
                    </br>In-charge: {{$task->in_charge}}</br> 
                <a href="{{route('home')}}">
                <input type="submit" value="Back" class="back">
                </a>
                </div>

            </div>
        </div>
    </div>
@endsection