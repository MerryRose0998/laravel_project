@extends('layout.master')

@section('title')
    Event List
@endsection
@section('content')
    <div class="container">
        <div class="col-md-10 offset-md-1">
            <br>
            <h5> <b>Events Management System</b></h5>
            </br>

            <br><a href="{{route('add')}}">
                <span class="glyphicon glyphicon-plus-sign"></span>
                </a>
            </br>
            
            <br>
            <div class="row" id="div_box1">
            @foreach ($tasks as $task)
                <div class="col-md-4 mb-5">
                    <div class="card" id="relative">
                        <a href="{{route('delete', $task->id)}}"> 
                        <button type="button" class="delete" onclick="return confirm('Are you sure to delete?');"></button>
                        </a>
                        
                            <h4><b>{{$task->task_column}}</b></h4>
                        <br>
                        <table>
                        <td>
                        <a href="{{route('view', $task->id)}}"> 
                            <button type="button" class="view">View</button>
                        </a>
                        <a href="{{route('edit', $task->id)}}"> 
                            <button type="button" class="edit">Edit</button>
                        </a>
                        </table>
                    
                    </div>
                </div>
            @endforeach  
            </div>  
        </div>
    </div>
@endsection