@extends('layout.master')

@section('title')
    Add Task
@endsection
@section('content')
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <h4>Add Task</h4>

            <form action="{{route('insert')}}" method="post">
                @csrf
                @method('post')
                <div class="form-group">
                    <label class="form-label"> Event Name: </label>
                    <input type="text" class="form-control" name="name_input" required placeholder="Enter task here">

                    <label class="form-label"> Date: </label>
                    <input type="date" class="form-control" name="date_input" required placeholder="Enter task here">

                    <label class="form-label"> Venue:</label>
                    <input type="text" class="form-control" name="venue_input" required placeholder="Enter task here">
                    
                    <label class="form-label"> In-charge:</label>
                    <input type="text" class="form-control" name="incharge_input" required placeholder="Enter task here">
                    
                    <input type="submit" value="create" class="mt-2 btn btn-info">
                    <a href="{{route('home')}}"> 
                            <button type="button" class="cancel">Cancel</button>
                        </a>
                </div>
            </form>
        </div>
    </div>
@endsection