@extends('layout.master')

@section('title')
    Edit Event
@endsection 
@section('content')
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <b>Edit Event</b>
            <div class="addbox">
                <form action="{{route('update', $task->id)}}" method="post">
                @csrf
                @method('post')
                <div class="form-group">
                    <label class="form-label"> Event Name: </label>
                    <input type="text" value="{{$task->task_column}}" class="form-control" name="name_input" required placeholder="Enter task here">

                    <label class="form-label"> Date: </label>
                    <input type="date" value="{{$task->date}}" class="form-control" name="date_input" required placeholder="Enter task here">

                    <label class="form-label"> Venue:</label>
                    <input type="text" value="{{$task->venue}}" class="form-control" name="venue_input" required placeholder="Enter task here">
                    
                    <label class="form-label"> In-charge:</label>
                    <input type="text" value="{{$task->in_charge}}" class="form-control" name="incharge_input" required placeholder="Enter task here">
                    
                    <input type="submit" value="update" class="mt-2 btn btn-info">
                    <a href="{{route('home')}}"> 
                            <button type="button" class="cancel">Cancel</button>
                        </a>
                </div>
                </form>
                        
                
            </div>          
        </div>
    </div>
@endsection