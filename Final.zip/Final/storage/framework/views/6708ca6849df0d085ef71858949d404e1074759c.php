

<?php $__env->startSection('title'); ?>
    Edit Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <b>Edit Event</b>
            <div class="addbox">
                <form action="<?php echo e(route('update', $task->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="form-group">
                    <label class="form-label"> Event Name: </label>
                    <input type="text" value="<?php echo e($task->task_column); ?>" class="form-control" name="name_input" required placeholder="Enter task here">

                    <label class="form-label"> Date: </label>
                    <input type="date" value="<?php echo e($task->date); ?>" class="form-control" name="date_input" required placeholder="Enter task here">

                    <label class="form-label"> Venue:</label>
                    <input type="text" value="<?php echo e($task->venue); ?>" class="form-control" name="venue_input" required placeholder="Enter task here">
                    
                    <label class="form-label"> In-charge:</label>
                    <input type="text" value="<?php echo e($task->in_charge); ?>" class="form-control" name="incharge_input" required placeholder="Enter task here">
                    
                    <input type="submit" value="update" class="mt-2 btn btn-info">
                    <a href="<?php echo e(route('home')); ?>"> 
                            <button type="button" class="cancel">Cancel</button>
                        </a>
                </div>
                </form>
                        
                
            </div>          
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Station\Desktop\act44\resources\views/pages/edit.blade.php ENDPATH**/ ?>