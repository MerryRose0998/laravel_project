

<?php $__env->startSection('title'); ?>
    To Do List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 offset-md-2">

        <a href="<?php echo e(route('add')); ?>" class="btn btn-primary">Add Task</a>
            <table class="table">
                <thead>
                    <tr>
                        <td><b>ID</b></td>
                        <td><b>Task</b></td>
                        <td><b>Done</b></td>
                        <td><b>Edit</b></td>
                        <td><b>Delete</b></td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($task->id); ?></td>
                        <td><?php echo e($task->task_column); ?></td>
                        <td>
                            <a href="<?php echo e(route('done', $task->id)); ?>">
                                <?php if($task->done === 0): ?>
                                    False
                                <?php else: ?>
                                    True                        
                                <?php endif; ?>
                            </a> 
                         </td>
                        <td><a href="<?php echo e(route('edit', $task->id)); ?>">Edit</a></td>
                        <td><a href="<?php echo e(route('delete', $task->id)); ?>" onclick="return confirm('Are you sure to delete?');">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\IT Elective 1\LARAVEL\act44\resources\views/pages/home.blade.php ENDPATH**/ ?>