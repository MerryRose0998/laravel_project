

<?php $__env->startSection('title'); ?>
    Event List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-10 offset-md-1">
            <br>
            <h5> <b>Events Management System</b></h5>
            </br>

            <br><a href="<?php echo e(route('add')); ?>">
                <span class="glyphicon glyphicon-plus-sign"></span>
                </a>
            </br>
            
            <br>
            <div class="row" id="div_box1">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-5">
                    <div class="card" id="relative">
                        <a href="<?php echo e(route('delete', $task->id)); ?>"> 
                        <button type="button" class="delete" onclick="return confirm('Are you sure to delete?');"></button>
                        </a>
                        
                            <h4><b><?php echo e($task->task_column); ?></b></h4>
                        <br>
                        <table>
                        <td>
                        <a href="<?php echo e(route('view', $task->id)); ?>"> 
                            <button type="button" class="view">View</button>
                        </a>
                        <a href="<?php echo e(route('edit', $task->id)); ?>"> 
                            <button type="button" class="edit">Edit</button>
                        </a>
                        </table>
                    
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>  
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Station\Desktop\act44\resources\views/pages/home.blade.php ENDPATH**/ ?>