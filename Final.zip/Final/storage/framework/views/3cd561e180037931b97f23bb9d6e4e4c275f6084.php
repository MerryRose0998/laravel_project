

<?php $__env->startSection('title'); ?>
    Add Task
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <h4>Add Task</h4>

            <form action="<?php echo e(route('insert')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="form-group">
                    <label class="form-label"> Event Name: </label>
                    <input type="text" class="form-control" name="name_input" required placeholder="Enter task here">

                    <label class="form-label"> Date: </label>
                    <input type="date" class="form-control" name="date_input" required placeholder="Enter task here">

                    <label class="form-label"> Venue:</label>
                    <input type="text" class="form-control" name="venue_input" required placeholder="Enter task here">
                    
                    <label class="form-label"> In-charge:</label>
                    <input type="text" class="form-control" name="incharge_input" required placeholder="Enter task here">
                    
                    <input type="submit" value="create" class="mt-2 btn btn-info">
                    <a href="<?php echo e(route('home')); ?>"> 
                            <button type="button" class="cancel">Cancel</button>
                        </a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Station\Desktop\act44\resources\views/pages/add.blade.php ENDPATH**/ ?>