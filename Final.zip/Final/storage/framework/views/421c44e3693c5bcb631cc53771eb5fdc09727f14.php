

<?php $__env->startSection('title'); ?>
    View Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 offset-md-2">
            
            <div class="addbox">
                <b>Event Details</b>
                <br><br><br>
                <div class="details">
                    </br>Schedule: <?php echo e($task->date); ?></br> 
                    </br>Venue: <?php echo e($task->venue); ?></br> 
                    </br>In-charge: <?php echo e($task->in_charge); ?></br> 
                <a href="<?php echo e(route('home')); ?>">
                <input type="submit" value="Back" class="back">
                </a>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Station\Desktop\act44\resources\views/pages/view.blade.php ENDPATH**/ ?>