<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;

class TaskController extends Controller
{
    public function show(){
        $tasks = Task::all();

        return view("pages.home")->with("tasks", $tasks);
    }

    public function insert(Request $request){

        $task = new Task();

        $task->task_column = $request->name_input;
        $task->date = $request->date_input;
        $task->venue= $request->venue_input;
        $task->in_charge = $request->incharge_input;
        

        $task->save();

        return redirect()->route('home');
    }
    public function view($id){

        $task = Task::find($id);
        return view("pages.view")->with("task", $task);
    }


    public function update(Request $request, $id){

        $task = Task::find($id);
        $task->task_column = $request->name_input;
        $task->date = $request->date_input;
        $task->venue= $request->venue_input;
        $task->in_charge = $request->incharge_input;
        $task->save();
        return redirect()->route('home');
    }
    public function edit($id){

        $task = Task::find($id);
        return view("pages.edit")->with("task", $task);
    }
    public function delete($id){

        $task = Task::find($id);
        
        $task->delete($id);
        
        return redirect()->route('home');
    }

}
